namespace CleanArchitecture.Domain.Users;

public record Nombre(string Value);